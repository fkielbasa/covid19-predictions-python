import customtkinter

def setup_appearance():
    customtkinter.set_appearance_mode("System")
    customtkinter.set_default_color_theme("blue")