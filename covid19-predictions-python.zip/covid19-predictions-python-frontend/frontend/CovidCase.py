
class CovidCase:
    def __init__(self, date: str, total: int, new: int) -> None:
        self.date = date
        self.total = total
        self.new = new
